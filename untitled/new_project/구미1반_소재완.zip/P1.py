import sys
sys.stdin = open('칠 영역의 개수 구하기_input.txt')

T = int(input())
for tc in range(1, T+1):
    b,c = map(int, input().split())
    data = [list(map(int,input().split())) for _ in range(c)]
    # print(data)

    G = [[0 for _ in range(b)] for _ in range(b)]
    # print(G)

    for i in range(len(data)):
        for k in range(data[i][2]-data[i][0]+1):
            for j in range(1,data[i][3]-data[i][1]+2):

                    G[data[i][k]][data[i][k] + + j] = 1

    cnt = 0
    for i in range(b):
        for j in range(b):
            if G[i][j] == 1:
                cnt += 1

print("#{} {}".format(tc, cnt))