import sys
sys.stdin = open('문제3_input.txt')